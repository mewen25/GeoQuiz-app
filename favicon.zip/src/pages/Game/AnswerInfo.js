import React from "react";

const AnswerInfo = props => {
  console.log("THING", props);
  return (
    <div>
      <h1>{props.guessInfo.click}</h1>
    </div>
  );
};

export default AnswerInfo;
