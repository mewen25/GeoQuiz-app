import React from "react";

const PointsPopup = () => {
  return <div></div>;
};

export default PointsPopup;
