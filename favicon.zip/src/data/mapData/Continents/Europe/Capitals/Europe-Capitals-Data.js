export default [
  {
    name: "Tirana"
  },
  {
    name: "Vienna"
  },
  {
    name: "Baku"
  },
  {
    name: "Minsk"
  },
  {
    name: "Brussels"
  },
  {
    name: "Sarajevo"
  },
  {
    name: "Sofia"
  },
  {
    name: "Zagreb"
  },
  //   {
  //     name: "Nicosia"
  //   },
  {
    name: "Prague"
  },
  {
    name: "Copenhagen"
  },
  {
    name: "Tallinn"
  },
  {
    name: "Helsinki"
  },
  {
    name: "Paris"
  },
  {
    name: "Tbilisi"
  },
  {
    name: "Berlin"
  },
  {
    name: "Athens"
  },
  {
    name: "Budapest"
  },
  {
    name: "Reykjavík"
  },
  {
    name: "Dublin"
  },
  {
    name: "Rome"
  },
  {
    name: "Prishtina"
  },
  {
    name: "Riga"
  },
  {
    name: "Vilnius"
  },
  {
    name: "Luxembourg"
  },
  {
    name: "Chisinau"
  },
  {
    name: "Podgorica"
  },
  {
    name: "Amsterdam"
  },
  {
    name: "Skopje"
  },
  {
    name: "Oslo"
  },
  {
    name: "Warsaw"
  },
  {
    name: "Lisbon"
  },
  {
    name: "Bucharest"
  },
  {
    name: "Moscow"
  },
  {
    name: "Belgrade"
  },
  {
    name: "Bratislava"
  },
  {
    name: "Ljubljana"
  },
  {
    name: "Madrid"
  },
  {
    name: "Stockholm"
  },
  {
    name: "Bern"
  },
  {
    name: "Ankara"
  },
  {
    name: "Kyiv"
  },
  {
    name: "London"
  }
];
