export default [
  {
    name: "Australia",
    capital: "N/A"
  },
  // {
  //   name: "Cook Islands",
  //   id: "Cook-Islands",
  //   capital: "N/A"
  // },
  {
    name: "Federated States of Micronesia",
    id: "Federated-States-of-Micronesia",
    capital: "N/A"
  },
  {
    name: "Fiji",
    capital: "N/A"
  },
  // {
  //   name: "French-Polynesia",
  //   id: "French-Polynesia",
  //   capital: "N/A"
  // },
  {
    name: "Kiribati",
    capital: "N/A"
  },
  {
    name: "Marshall Islands",
    id: "Marshall-Islands",
    capital: "N/A"
  },
  {
    name: "Nauru",
    capital: "N/A"
  },
  {
    name: "New Zealand",
    id: "New-Zealand",
    capital: "N/A"
  },
  // {
  //   name: "Niue",
  //   capital: "N/A"
  // },
  {
    name: "Palau",
    capital: "N/A"
  },
  {
    name: "Papua New Guinea",
    id: "Papua-New-Guinea",
    capital: "N/A"
  },
  {
    name: "Samoa",
    capital: "N/A"
  },
  {
    name: "Solomon Islands",
    id: "Solomon-Islands",
    capital: "N/A"
  },
  {
    name: "Tonga",
    capital: "N/A"
  },
  {
    name: "Tuvalu",
    capital: "N/A"
  },
  {
    name: "Vanuatu",
    capital: "N/A"
  }
];
