export default [
  {
    name: "Algeria",
    capital: "N/A"
  },
  {
    name: "Angola",
    capital: "N/A"
  },
  {
    name: "Benin",
    capital: "N/A"
  },
  {
    name: "Botswana",
    capital: "N/A"
  },
  {
    name: "Burkina Faso",
    id: "Burkina-Faso",
    capital: "N/A"
  },
  {
    name: "Burundi",
    capital: "N/A"
  },
  {
    name: "Cabo Verde",
    id: "Cabo-Verde",
    capital: "N/A"
  },
  {
    name: "Cameroon",
    capital: "N/A"
  },
  {
    name: "Central African Republic",
    id: "Central-African-Republic",
    capital: "N/A"
  },
  {
    name: "Chad",
    capital: "N/A"
  },
  {
    name: "Comoros",
    capital: "N/A"
  },
  {
    name: "Côte d'Ivoire",
    id: "Côte-d-Ivoire",
    capital: "N/A"
  },
  {
    name: "Djibouti",
    capital: "N/A"
  },
  {
    name: "Democratic Republic of the Congo",
    id: "DR-Congo",
    capital: "N/A"
  },
  {
    name: "Egypt",
    capital: "N/A"
  },
  {
    name: "Equatorial Guinea",
    id: "Equatorial-Guinea",
    capital: "N/A"
  },
  {
    name: "Eritrea",
    capital: "N/A"
  },
  {
    name: "Eswatini",
    capital: "N/A"
  },
  {
    name: "Ethiopia",
    capital: "N/A"
  },
  {
    name: "Gabon",
    capital: "N/A"
  },
  {
    name: "Gambia",
    capital: "N/A"
  },
  {
    name: "Ghana",
    capital: "N/A"
  },
  {
    name: "Guinea",
    capital: "N/A"
  },
  {
    name: "Guinea Bissau",
    id: "Guinea-Bissau",
    capital: "N/A"
  },
  {
    name: "Kenya",
    capital: "N/A"
  },
  {
    name: "Lesotho",
    capital: "N/A"
  },
  {
    name: "Liberia",
    capital: "N/A"
  },
  {
    name: "Libya",
    capital: "N/A"
  },
  {
    name: "Madagascar",
    capital: "N/A"
  },
  {
    name: "Malawi",
    capital: "N/A"
  },
  {
    name: "Mali",
    capital: "N/A"
  },
  {
    name: "Mauritania",
    capital: "N/A"
  },
  {
    name: "Mauritius",
    capital: "N/A"
  },
  {
    name: "Morocco",
    capital: "N/A"
  },
  {
    name: "Mozambique",
    capital: "N/A"
  },
  {
    name: "Namibia",
    capital: "N/A"
  },
  {
    name: "Niger",
    capital: "N/A"
  },
  {
    name: "Nigeria",
    capital: "N/A"
  },
  {
    name: "Republic of the Congo",
    id: "Congo",
    capital: "N/A"
  },
  {
    name: "Rwanda",
    capital: "N/A"
  },
  {
    name: "Sao Tome and Principe",
    id: "Sao-Tome-and-Principe",
    capital: "N/A"
  },
  {
    name: "Senegal",
    capital: "N/A"
  },
  {
    name: "Seychelles",
    capital: "N/A"
  },
  {
    name: "Sierra Leone",
    id: "Sierra-Leone",
    capital: "N/A"
  },
  {
    name: "Somalia",
    capital: "N/A"
  },
  {
    name: "South Africa",
    id: "South-Africa",
    capital: "N/A"
  },
  {
    name: "South Sudan",
    id: "South-Sudan",
    capital: "N/A"
  },
  {
    name: "Sudan",
    capital: "N/A"
  },
  {
    name: "Tanzania",
    capital: "N/A"
  },
  {
    name: "Togo",
    capital: "N/A"
  },
  {
    name: "Tunisia",
    capital: "N/A"
  },
  {
    name: "Uganda",
    capital: "N/A"
  },
  {
    name: "Western Sahara (Disputed Territory)",
    id: "Western-Sahara",
    capital: "N/A"
  },
  {
    name: "Zambia",
    capital: "N/A"
  },
  {
    name: "Zimbabwe",
    capital: "N/A"
  }
];
