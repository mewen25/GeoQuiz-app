export default [
  {
    name: "Afghanistan",
    capital: "Kabul"
  },
  {
    name: "Armenia",
    capital: "Yerevan"
  },
  {
    name: "Azerbaijan",
    capital: "Baku"
  },
  {
    name: "Bahrain",
    capital: "Manama"
  },
  {
    name: "Bangladesh",
    capital: "N/A"
  },
  {
    name: "Bhutan",
    capital: "N/A"
  },
  {
    name: "Brunei",
    capital: "N/A"
  },
  {
    name: "Cambodia",
    capital: "N/A"
  },
  {
    name: "China",
    capital: "N/A"
  },
  // {
  //   name: "Cyprus",
  //   capital: "N/A"
  // },
  {
    name: "Georgia",
    capital: "N/A"
  },
  {
    name: "India",
    capital: "N/A"
  },
  {
    name: "Indonesia",
    capital: "N/A"
  },
  {
    name: "Iran",
    capital: "N/A"
  },
  {
    name: "Iraq",
    capital: "N/A"
  },
  {
    name: "Israel",
    capital: "N/A"
  },
  {
    name: "Japan",
    capital: "N/A"
  },
  {
    name: "Jordan",
    capital: "N/A"
  },
  {
    name: "Kazakhstan",
    capital: "N/A"
  },
  {
    name: "Kuwait",
    capital: "N/A"
  },
  {
    name: "Kyrgyzstan",
    capital: "N/A"
  },
  {
    name: "Laos",
    capital: "N/A"
  },
  {
    name: "Lebanon",
    capital: "N/A"
  },
  {
    name: "Malaysia",
    capital: "N/A"
  },
  {
    name: "Maldives",
    capital: "N/A"
  },
  {
    name: "Mongolia",
    capital: "N/A"
  },
  {
    name: "Myanmar",
    capital: "N/A"
  },
  {
    name: "Nepal",
    capital: "N/A"
  },
  {
    name: "North Korea",
    id: "North-Korea",
    capital: "N/A"
  },
  {
    name: "Oman",
    capital: "N/A"
  },
  {
    name: "Pakistan",
    capital: "N/A"
  },
  {
    name: "Philippines",
    capital: "N/A"
  },
  {
    name: "Qatar",
    capital: "N/A"
  },
  {
    name: "Russia",
    capital: "Moscow"
  },
  {
    name: "Saudi Arabia",
    id: "Saudi-Arabia",
    capital: "N/A"
  },
  {
    name: "Singapore",
    capital: "N/A"
  },
  {
    name: "South Korea",
    id: "South-Korea",
    capital: "N/A"
  },
  {
    name: "Sri Lanka",
    id: "Sri-Lanka",
    capital: "N/A"
  },
  // {
  //   name: "State of Palestine",
  //   id: "State-of-Palestine",
  //   capital: "N/A"
  // },
  {
    name: "Syria",
    capital: "N/A"
  },
  {
    name: "Taiwan",
    cappital: "N/A"
  },
  {
    name: "Tajikistan",
    capital: "N/A"
  },
  {
    name: "Thailand",
    capital: "N/A"
  },
  {
    name: "Timor Leste",
    id: "Timor-Leste",
    capital: "Dili"
  },
  {
    name: "Turkey",
    capital: "N/A"
  },
  {
    name: "Turkmenistan",
    capital: "N/A"
  },
  {
    name: "United Arab Emirates",
    id: "United-Arab-Emirates",
    capital: "N/A"
  },
  {
    name: "Uzbekistan",
    capital: "N/A"
  },
  {
    name: "Vietnam",
    capital: "N/A"
  },
  {
    name: "Yemen",
    capital: "N/A"
  }
];
