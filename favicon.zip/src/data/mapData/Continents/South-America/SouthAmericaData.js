export default [
  {
    name: "Brazil",
    capital: "N/A"
  },
  {
    name: "Colombia",
    capital: "N/A"
  },
  {
    name: "Argentina",
    capital: "N/A"
  },
  {
    name: "Peru",
    capital: "N/A"
  },
  {
    name: "Venezuela",
    capital: "N/A"
  },
  {
    name: "Chile",
    capital: "N/A"
  },
  {
    name: "Ecuador",
    capital: "N/A"
  },
  {
    name: "Bolivia",
    capital: "N/A"
  },
  {
    name: "Paraguay",
    capital: "N/A"
  },
  {
    name: "Uruguay",
    capital: "N/A"
  },
  {
    name: "Guyana",
    capital: "N/A"
  },
  {
    name: "Suriname",
    capital: "N/A"
  },
  {
    name: "French Guiana",
    id: "French-Guiana",
    capital: "N/A"
  }
];
