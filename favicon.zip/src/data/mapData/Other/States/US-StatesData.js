export default [
  {
    name: "Alabama",
    capital: "N/A"
  },
  {
    name: "Alaska",
    capital: "N/A"
  },
  {
    name: "Arizona",
    capital: "N/A"
  },
  {
    name: "Arkansas",
    capital: "N/A"
  },
  {
    name: "California",
    capital: "N/A"
  },
  {
    name: "Colorado",
    capital: "N/A"
  },
  {
    name: "Connecticut",
    capital: "N/A"
  },
  {
    name: "Delaware",
    capital: "N/A"
  },
  {
    name: "Florida",
    capital: "N/A"
  },
  {
    name: "Georgia",
    capital: "N/A"
  },
  {
    name: "Hawaii",
    capital: "N/A"
  },
  {
    name: "Idaho",
    capital: "N/A"
  },
  {
    name: "Illinois",
    capital: "N/A"
  },
  {
    name: "Indiana",
    capital: "N/A"
  },
  {
    name: "Iowa",
    capital: "N/A"
  },
  {
    name: "Kansas",
    capital: "N/A"
  },
  {
    name: "Kentucky",
    capital: "N/A"
  },
  {
    name: "Louisiana",
    capital: "N/A"
  },
  {
    name: "Maine",
    capital: "N/A"
  },
  {
    name: "Maryland",
    capital: "N/A"
  },
  {
    name: "Massachusetts",
    capital: "N/A"
  },
  {
    name: "Michigan",
    capital: "N/A"
  },
  {
    name: "Minnesota",
    capital: "N/A"
  },
  {
    name: "Mississippi",
    capital: "N/A"
  },
  {
    name: "Missouri",
    capital: "N/A"
  },
  {
    name: "Montana",
    capital: "N/A"
  },
  {
    name: "Nebraska",
    capital: "N/A"
  },
  {
    name: "Nevada",
    capital: "N/A"
  },
  {
    id: "New-Hampshire",
    name: "New Hampshire",
    capital: "N/A"
  },
  {
    id: "New-Jersey",
    name: "New Jersey",
    capital: "N/A"
  },
  {
    id: "New-Mexico",
    name: "New Mexico",
    capital: "N/A"
  },
  {
    id: "New-York",
    name: "New York",
    capital: "N/A"
  },
  {
    id: "North-Carolina",
    name: "North Carolina",
    capital: "N/A"
  },
  {
    id: "North-Dakota",
    name: "North Dakota",
    capital: "N/A"
  },
  {
    name: "Ohio",
    capital: "N/A"
  },
  {
    name: "Oklahoma",
    capital: "N/A"
  },
  {
    name: "Oregon",
    capital: "N/A"
  },
  {
    name: "Pennsylvania",
    capital: "N/A"
  },
  {
    id: "Rhode-Island",
    name: "Rhode Island",
    capital: "N/A"
  },
  {
    id: "South-Carolina",
    name: "South Carolina",
    capital: "N/A"
  },
  {
    id: "South-Dakota",
    name: "South Dakota",
    capital: "N/A"
  },
  {
    name: "Tennessee",
    capital: "N/A"
  },
  {
    name: "Texas",
    capital: "N/A"
  },
  {
    name: "Utah",
    capital: "N/A"
  },
  {
    name: "Vermont",
    capital: "N/A"
  },
  {
    name: "Virginia",
    capital: "N/A"
  },
  {
    name: "Washington",
    capital: "N/A"
  },
  {
    id: "West-Virginia",
    name: "West Virginia",
    capital: "N/A"
  },
  {
    name: "Wisconsin",
    capital: "N/A"
  },
  {
    name: "Wyoming",
    capital: "N/A"
  }
];
